---
title: 待删除教程
difficulty: apprentice
---
这篇教程将随内容包删除一并消失。
