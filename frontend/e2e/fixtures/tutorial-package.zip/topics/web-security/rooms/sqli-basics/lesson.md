---
title: SQL 注入基础
difficulty: apprentice
flow:
  - 观察正常响应
  - 探测列数
  - 构造 UNION 查询
---
SQL 注入教程正文。了解 [SQL 注入](#knowledge:sql-injection)。

## 原理背景

注入点来自字符串拼接，先用单引号判断闭合方式，再用 UNION 回显数据。

1. 探测列数
2. 构造 UNION 查询

- 先手工验证单条 payload
